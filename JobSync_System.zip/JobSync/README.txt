JOBSYNC - PF 101 OOP PERFORMANCE TASK
=====================================

Find Your Fit. Get Hired.

TECHNOLOGY
- Java
- Java Swing GUI
- TXT file storage (no database)

REQUIREMENTS
- JDK 17 or newer recommended
- No external libraries required

RUN IN VS CODE / TERMINAL
1. Open the JobSync folder.
2. Compile:
   javac -d out src/*.java
3. Run:
   java -cp out Main

DEMO ACCOUNTS
Applicant:
  username: applicant
  password: 1234

Employer:
  username: employer
  password: 1234

DATA FILES
data/users.txt
data/jobs.txt
data/applications.txt
data/appointments.txt

MAIN FEATURES
Applicant:
- Register/login
- Search jobs by title, location, or minimum salary
- Apply for jobs
- View/withdraw applications
- View interview appointments
- Edit resume/profile

Employer:
- Register/login
- Post full-time or part-time jobs
- View own postings
- Close/delete postings
- Review applications
- Accept/reject applicants
- Schedule interviews

OOP REQUIREMENTS IMPLEMENTED
- Encapsulation: private fields + getters/setters
- Inheritance: Applicant/Employer extend User; PartTimeJob/FullTimeJob extend JobPosting
- Polymorphism: overridden displayMenu(), getBenefits(), computeMonthlySalary()
- Overloading: JobManager.search() has 3 versions
- Abstraction: User and JobPosting are abstract; FileHandler hides file I/O

FILE FORMAT
The TXT files use | as a separator. Avoid entering the | character in fields.

NOTE
This implementation follows the supplied JobSync proposal: Java OOP, GUI, and TXT-file persistence.
