public abstract class JobPosting {
    protected String jobId;
    protected String title;
    protected String description;
    protected String location;
    protected String requiredSkills;
    protected double salary;
    protected String employerId;
    protected String status;

    public JobPosting(String jobId, String title, String description, String location,
                      String requiredSkills, double salary, String employerId, String status) {
        this.jobId = jobId;
        this.title = title;
        this.description = description;
        this.location = location;
        this.requiredSkills = requiredSkills;
        this.salary = salary;
        this.employerId = employerId;
        this.status = status;
    }

    public String getJobId() { return jobId; }
    public String getTitle() { return title; }
    public String getDescription() { return description; }
    public String getLocation() { return location; }
    public String getRequiredSkills() { return requiredSkills; }
    public double getSalary() { return salary; }
    public String getEmployerId() { return employerId; }
    public String getStatus() { return status; }

    public void setTitle(String v) { title = v; }
    public void setDescription(String v) { description = v; }
    public void setLocation(String v) { location = v; }
    public void setRequiredSkills(String v) { requiredSkills = v; }
    public void setSalary(double v) { salary = v; }
    public void setStatus(String v) { status = v; }

    public abstract String getBenefits();
    public abstract double computeMonthlySalary();

    public String toFileString() {
        return String.join("|", jobId, getType(), title, description, location,
                requiredSkills, String.valueOf(salary), employerId, status, getExtra());
    }

    protected abstract String getType();
    protected abstract String getExtra();

    public static JobPosting fromFileString(String line) {
        String[] p = line.split("\\|", -1);
        if (p.length < 10) return null;
        try {
            if ("PART_TIME".equals(p[1])) {
                return new PartTimeJob(p[0],p[2],p[3],p[4],p[5],Double.parseDouble(p[6]),p[7],p[8],Integer.parseInt(p[9]));
            }
            return new FullTimeJob(p[0],p[2],p[3],p[4],p[5],Double.parseDouble(p[6]),p[7],p[8],p[9]);
        } catch (Exception e) {
            return null;
        }
    }
}
