public class PartTimeJob extends JobPosting {
    private int hoursPerWeek;

    public PartTimeJob(String id, String title, String description, String location,
                       String skills, double salary, String employerId, String status,
                       int hoursPerWeek) {
        super(id,title,description,location,skills,salary,employerId,status);
        this.hoursPerWeek = hoursPerWeek;
    }

    public int getHoursPerWeek() { return hoursPerWeek; }
    public void setHoursPerWeek(int h) { hoursPerWeek = h; }

    @Override public String getBenefits() {
        return "Flexible schedule; " + hoursPerWeek + " hours/week";
    }

    @Override public double computeMonthlySalary() {
        return salary * hoursPerWeek * 4.0;
    }

    @Override protected String getType() { return "PART_TIME"; }
    @Override protected String getExtra() { return String.valueOf(hoursPerWeek); }
}
