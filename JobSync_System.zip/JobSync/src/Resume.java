public class Resume {
    private String education;
    private String skills;
    private String experience;

    public Resume(String education, String skills, String experience) {
        this.education = education;
        this.skills = skills;
        this.experience = experience;
    }

    public String getEducation() { return education; }
    public String getSkills() { return skills; }
    public String getExperience() { return experience; }

    public void setEducation(String education) { this.education = education; }
    public void setSkills(String skills) { this.skills = skills; }
    public void setExperience(String experience) { this.experience = experience; }

    public boolean matchesSkills(String required) {
        if (required == null || required.trim().isEmpty()) return true;
        String have = skills.toLowerCase();
        for (String skill : required.split(",")) {
            if (!have.contains(skill.trim().toLowerCase())) return false;
        }
        return true;
    }
}
