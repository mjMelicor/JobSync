import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class Main {
    private static final Color NAVY = new Color(25, 43, 73);
    private static final Color BLUE = new Color(43, 96, 176);
    private static JFrame frame;
    private static User currentUser;

    public static void main(String[] args) {
        ensureData();
        SwingUtilities.invokeLater(Main::showLogin);
    }

    private static void ensureData() {
        FileHandler.readAll(FileHandler.USERS_FILE);
        FileHandler.readAll(FileHandler.JOBS_FILE);
        FileHandler.readAll(FileHandler.APPLICATIONS_FILE);
        FileHandler.readAll(FileHandler.APPOINTMENTS_FILE);
    }

    private static void base(String title) {
        frame = new JFrame(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1050, 700);
        frame.setLocationRelativeTo(null);
    }

    private static JPanel panel() {
        JPanel p = new JPanel();
        p.setBorder(new EmptyBorder(18,18,18,18));
        return p;
    }

    private static JButton btn(String text) {
        JButton b = new JButton(text);
        b.setFocusPainted(false);
        return b;
    }

    private static void showLogin() {
        base("JobSync - Login");
        JPanel root = new JPanel(new BorderLayout(15,15));
        root.setBorder(new EmptyBorder(35,45,35,45));

        JLabel title = new JLabel("<html><h1>JobSync</h1><p>Find Your Fit. Get Hired.</p></html>");
        title.setForeground(NAVY);
        root.add(title, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8,8,8,8);
        g.fill = GridBagConstraints.HORIZONTAL;

        JTextField user = new JTextField(22);
        JPasswordField pass = new JPasswordField(22);
        JButton login = btn("Login");
        JButton register = btn("Create Account");

        g.gridx=0; g.gridy=0; form.add(new JLabel("Username:"),g);
        g.gridx=1; form.add(user,g);
        g.gridx=0; g.gridy=1; form.add(new JLabel("Password:"),g);
        g.gridx=1; form.add(pass,g);
        g.gridx=0; g.gridy=2; form.add(login,g);
        g.gridx=1; form.add(register,g);
        root.add(form, BorderLayout.CENTER);

        login.addActionListener(e -> {
            User u = authenticate(user.getText().trim(), new String(pass.getPassword()));
            if (u == null) {
                JOptionPane.showMessageDialog(frame,"Invalid username or password.","Login",JOptionPane.ERROR_MESSAGE);
            } else {
                currentUser=u;
                showDashboard();
            }
        });
        register.addActionListener(e -> showRegister());
        frame.setContentPane(root);
        frame.setVisible(true);
    }

    private static User authenticate(String username, String password) {
        for (String line : FileHandler.readAll(FileHandler.USERS_FILE)) {
            String[] p=line.split("\\|",-1);
            if (p.length>=8 && p[2].equals(username) && p[3].equals(password)) {
                if (p[1].equals("Applicant")) {
                    Resume r = new Resume(p[5],p[6],p[7]);
                    return new Applicant(p[0],p[2],p[3],p[4],p.length>8?p[8]:"",r);
                } else {
                    return new Employer(p[0],p[2],p[3],p[4],p[5],p[6]);
                }
            }
        }
        return null;
    }

    private static void showRegister() {
        base("JobSync - Registration");
        JPanel root=panel();
        root.setLayout(new BorderLayout(10,10));
        JLabel h=new JLabel("Create a JobSync Account");
        h.setFont(new Font("SansSerif",Font.BOLD,24));
        root.add(h,BorderLayout.NORTH);

        JPanel f=new JPanel(new GridLayout(0,2,8,8));
        JComboBox<String> role=new JComboBox<>(new String[]{"Applicant","Employer"});
        JTextField name=new JTextField(), username=new JTextField(), contact=new JTextField();
        JPasswordField password=new JPasswordField();
        JTextField company=new JTextField(), address=new JTextField();
        JTextField education=new JTextField(), skills=new JTextField(), experience=new JTextField();

        f.add(new JLabel("Account Type")); f.add(role);
        f.add(new JLabel("Full Name")); f.add(name);
        f.add(new JLabel("Username")); f.add(username);
        f.add(new JLabel("Password")); f.add(password);
        f.add(new JLabel("Contact Number")); f.add(contact);
        f.add(new JLabel("Company Name (Employer)")); f.add(company);
        f.add(new JLabel("Company Address (Employer)")); f.add(address);
        f.add(new JLabel("Education (Applicant)")); f.add(education);
        f.add(new JLabel("Skills (Applicant, comma-separated)")); f.add(skills);
        f.add(new JLabel("Experience (Applicant)")); f.add(experience);
        root.add(f,BorderLayout.CENTER);

        JButton save=btn("Register"), back=btn("Back");
        JPanel buttons=new JPanel(); buttons.add(save); buttons.add(back);
        root.add(buttons,BorderLayout.SOUTH);

        role.addActionListener(e -> {
            boolean a=role.getSelectedItem().equals("Applicant");
            contact.setEnabled(a); education.setEnabled(a); skills.setEnabled(a); experience.setEnabled(a);
            company.setEnabled(!a); address.setEnabled(!a);
        });
        role.setSelectedIndex(0);
        save.addActionListener(e -> {
            String u=username.getText().trim(), p=new String(password.getPassword());
            if(name.getText().trim().isEmpty()||u.isEmpty()||p.isEmpty()){
                JOptionPane.showMessageDialog(frame,"Full name, username and password are required."); return;
            }
            for(String line:FileHandler.readAll(FileHandler.USERS_FILE)){
                String[] x=line.split("\\|",-1);
                if(x.length>2 && x[2].equals(u)){ JOptionPane.showMessageDialog(frame,"Username already exists."); return; }
            }
            String id="U"+System.currentTimeMillis();
            if(role.getSelectedItem().equals("Applicant")){
                FileHandler.appendLine(FileHandler.USERS_FILE,
                    String.join("|",id,"Applicant",u,p,name.getText().trim(),
                    education.getText().trim(),skills.getText().trim(),experience.getText().trim(),contact.getText().trim()));
            } else {
                FileHandler.appendLine(FileHandler.USERS_FILE,
                    String.join("|",id,"Employer",u,p,name.getText().trim(),
                    company.getText().trim(),address.getText().trim(),"",""));
            }
            JOptionPane.showMessageDialog(frame,"Registration successful. You can now log in.");
            showLogin();
        });
        back.addActionListener(e->showLogin());
        frame.setContentPane(root); frame.setVisible(true);
    }

    private static void showDashboard() {
        base("JobSync - Dashboard");
        JPanel root=new JPanel(new BorderLayout());
        JPanel header=new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        JLabel h=new JLabel("  JobSync  |  "+currentUser.getFullName());
        h.setForeground(Color.WHITE); h.setFont(new Font("SansSerif",Font.BOLD,20));
        header.add(h,BorderLayout.WEST);
        JButton logout=btn("Logout"); header.add(logout,BorderLayout.EAST);
        root.add(header,BorderLayout.NORTH);
        logout.addActionListener(e->{currentUser=null;showLogin();});

        JPanel menu=new JPanel(new GridLayout(0,1,8,8));
        menu.setBorder(new EmptyBorder(20,20,20,20));
        if(currentUser instanceof Applicant){
            addMenu(menu,"Search Jobs",e->searchJobs());
            addMenu(menu,"My Applications",e->myApplications());
            addMenu(menu,"My Appointments",e->myAppointments());
            addMenu(menu,"My Resume / Profile",e->editApplicant());
        } else {
            addMenu(menu,"My Job Postings",e->myPostings());
            addMenu(menu,"Post New Job",e->postJob());
            addMenu(menu,"Review Applications",e->reviewApplications());
        }
        JLabel welcome=new JLabel("<html><div style='padding:25px'><h2>Welcome to JobSync</h2>"
            +"<p>Find Your Fit. Get Hired.</p><p>Select an option from the menu.</p></div></html>");
        root.add(menu,BorderLayout.WEST); root.add(welcome,BorderLayout.CENTER);
        frame.setContentPane(root); frame.setVisible(true);
    }

    private static void addMenu(JPanel p,String text,java.awt.event.ActionListener a){
        JButton b=btn(text); b.addActionListener(a); p.add(b);
    }

    private static void searchJobs() {
        JPanel root=panel(); root.setLayout(new BorderLayout(10,10));
        JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JTextField title=new JTextField(14), location=new JTextField(14), min=new JTextField(8);
        JButton search=btn("Search"), all=btn("All Open Jobs"), apply=btn("Apply Selected");
        top.add(new JLabel("Title"));top.add(title);top.add(new JLabel("Location"));top.add(location);
        top.add(new JLabel("Min Salary"));top.add(min);top.add(search);top.add(all);
        root.add(top,BorderLayout.NORTH);
        DefaultListModel<JobPosting> model=new DefaultListModel<>();
        JList<JobPosting> list=new JList<>(model);
        list.setCellRenderer(new DefaultListCellRenderer(){
            public Component getListCellRendererComponent(JList<?> l,Object v,int i,boolean s,boolean f){
                super.getListCellRendererComponent(l,v,i,s,f);
                JobPosting j=(JobPosting)v;
                setText(j.getTitle()+" | "+j.getLocation()+" | ₱"+String.format("%.2f",j.getSalary())
                    +" | "+j.getBenefits());
                return this;
            }
        });
        root.add(new JScrollPane(list),BorderLayout.CENTER);
        JPanel bottom=new JPanel(); bottom.add(apply); root.add(bottom,BorderLayout.SOUTH);

        Runnable loadAll=()->{model.clear();for(JobPosting j:JobManager.getAllJobs())if(j.getStatus().equals("Open"))model.addElement(j);};
        all.addActionListener(e->loadAll.run());
        search.addActionListener(e->{
            model.clear();
            String t=title.getText().trim(), loc=location.getText().trim();
            try{
                if(!min.getText().trim().isEmpty()){
                    for(JobPosting j:JobManager.search(Double.parseDouble(min.getText().trim()))) model.addElement(j);
                } else if(!loc.isEmpty()){
                    for(JobPosting j:JobManager.search(t,loc)) model.addElement(j);
                } else {
                    for(JobPosting j:JobManager.search(t)) model.addElement(j);
                }
            }catch(Exception ex){JOptionPane.showMessageDialog(frame,"Minimum salary must be a number.");}
        });
        apply.addActionListener(e->{
            JobPosting j=list.getSelectedValue();
            if(j==null){JOptionPane.showMessageDialog(frame,"Select a job first.");return;}
            for(String x:((Applicant)currentUser).viewMyApplications()){
                String[] a=x.split("\\|",-1); if(a.length>=3&&a[2].equals(j.getJobId())){
                    JOptionPane.showMessageDialog(frame,"You already applied for this job.");return;
                }
            }
            ((Applicant)currentUser).applyForJob(j.getJobId());
            JOptionPane.showMessageDialog(frame,"Application submitted.");
        });
        showPanel("Job Search",root);
        loadAll.run();
    }

    private static void myApplications(){
        JPanel p=panel();p.setLayout(new BorderLayout(10,10));
        JTextArea area=new JTextArea(); area.setEditable(false);
        StringBuilder sb=new StringBuilder();
        for(String line:((Applicant)currentUser).viewMyApplications()){
            String[] a=line.split("\\|",-1);
            String title=findJobTitle(a.length>2?a[2]:"");
            sb.append("Application ID: ").append(a[0]).append("\nJob: ").append(title)
              .append("\nDate: ").append(a[3]).append("\nStatus: ").append(a[4]).append("\n\n");
        }
        area.setText(sb.length()==0?"No applications yet.":sb.toString());
        p.add(new JScrollPane(area),BorderLayout.CENTER);
        JPanel b=new JPanel();JTextField id=new JTextField(12);JButton w=btn("Withdraw Selected ID");
        b.add(new JLabel("Application ID:"));b.add(id);b.add(w);p.add(b,BorderLayout.SOUTH);
        w.addActionListener(e->{((Applicant)currentUser).withdrawApplication(id.getText().trim());myApplications();});
        showPanel("My Applications",p);
    }

    private static void myAppointments(){
        JPanel p=panel();p.setLayout(new BorderLayout());
        JTextArea a=new JTextArea();a.setEditable(false);
        StringBuilder s=new StringBuilder();
        for(String line:((Applicant)currentUser).viewMyAppointments()){
            String[] x=line.split("\\|",-1);
            if(x.length>=5)s.append("Appointment: ").append(x[0]).append("\nDate: ").append(x[2])
                .append("\nTime: ").append(x[3]).append("\nPlace: ").append(x[4]).append("\n\n");
        }
        a.setText(s.length()==0?"No interview appointments.":s.toString());
        p.add(new JScrollPane(a));showPanel("My Appointments",p);
    }

    private static String findJobTitle(String id){
        for(JobPosting j:JobManager.getAllJobs())if(j.getJobId().equals(id))return j.getTitle();
        return "Unknown Job";
    }

    private static void editApplicant(){
        Applicant a=(Applicant)currentUser;
        JPanel f=panel();f.setLayout(new GridLayout(0,2,8,8));
        JTextField name=new JTextField(a.getFullName()), contact=new JTextField(a.getContactNumber());
        JTextField edu=new JTextField(a.getResume().getEducation()), skills=new JTextField(a.getResume().getSkills());
        JTextField exp=new JTextField(a.getResume().getExperience());
        f.add(new JLabel("Full Name"));f.add(name);f.add(new JLabel("Contact"));f.add(contact);
        f.add(new JLabel("Education"));f.add(edu);f.add(new JLabel("Skills"));f.add(skills);
        f.add(new JLabel("Experience"));f.add(exp);
        JButton save=btn("Save Resume");f.add(save);
        save.addActionListener(e->{
            ArrayList<String> out=new ArrayList<>();
            for(String line:FileHandler.readAll(FileHandler.USERS_FILE)){
                String[] p=line.split("\\|",-1);
                if(p.length>=9 && p[0].equals(a.getUserId())){
                    line=String.join("|",p[0],p[1],p[2],p[3],name.getText(),edu.getText(),skills.getText(),exp.getText(),contact.getText());
                }
                out.add(line);
            }
            FileHandler.writeAll(FileHandler.USERS_FILE,out);
            a.setContactNumber(contact.getText());a.getResume().setEducation(edu.getText());
            a.getResume().setSkills(skills.getText());a.getResume().setExperience(exp.getText());
            JOptionPane.showMessageDialog(frame,"Profile updated.");
        });
        showPanel("My Resume / Profile",f);
    }

    private static void myPostings(){
        Employer e=(Employer)currentUser;
        JPanel p=panel();p.setLayout(new BorderLayout(8,8));
        DefaultListModel<JobPosting> m=new DefaultListModel<>();
        for(JobPosting j:JobManager.getJobsForEmployer(e.getUserId()))m.addElement(j);
        JList<JobPosting> list=new JList<>(m);
        list.setCellRenderer(new DefaultListCellRenderer(){
            public Component getListCellRendererComponent(JList<?> l,Object v,int i,boolean s,boolean f){
                super.getListCellRendererComponent(l,v,i,s,f);JobPosting j=(JobPosting)v;
                setText(j.getTitle()+" | "+j.getLocation()+" | "+j.getStatus()+" | ₱"+String.format("%.2f",j.getSalary()));
                return this;
            }});
        p.add(new JScrollPane(list),BorderLayout.CENTER);
        JPanel b=new JPanel();JButton close=btn("Close Selected");JButton del=btn("Delete Selected");
        b.add(close);b.add(del);p.add(b,BorderLayout.SOUTH);
        close.addActionListener(x->{JobPosting j=list.getSelectedValue();if(j!=null){j.setStatus("Closed");JobManager.updateJob(j);myPostings();}});
        del.addActionListener(x->{JobPosting j=list.getSelectedValue();if(j!=null){JobManager.deleteJob(j.getJobId());myPostings();}});
        showPanel("My Job Postings",p);
    }

    private static void postJob(){
        JPanel f=panel();f.setLayout(new GridLayout(0,2,8,8));
        JTextField title=new JTextField(),desc=new JTextField(),loc=new JTextField(),skills=new JTextField(),salary=new JTextField(),extra=new JTextField();
        JComboBox<String> type=new JComboBox<>(new String[]{"Full-Time","Part-Time"});
        f.add(new JLabel("Job Type"));f.add(type);f.add(new JLabel("Title"));f.add(title);f.add(new JLabel("Description"));f.add(desc);
        f.add(new JLabel("Location"));f.add(loc);f.add(new JLabel("Required Skills"));f.add(skills);f.add(new JLabel("Salary"));
        f.add(salary);f.add(new JLabel("Schedule (full-time) / Hours per Week (part-time)"));f.add(extra);
        JButton save=btn("Post Job");f.add(save);
        save.addActionListener(e->{
            try{
                double sal=Double.parseDouble(salary.getText().trim());String id="J"+System.currentTimeMillis();
                JobPosting j;
                if(type.getSelectedItem().equals("Part-Time"))
                    j=new PartTimeJob(id,title.getText(),desc.getText(),loc.getText(),skills.getText(),sal,currentUser.getUserId(),"Open",Integer.parseInt(extra.getText()));
                else
                    j=new FullTimeJob(id,title.getText(),desc.getText(),loc.getText(),skills.getText(),sal,currentUser.getUserId(),"Open",extra.getText());
                JobManager.addJob(j);JOptionPane.showMessageDialog(frame,"Job posted successfully.");showDashboard();
            }catch(Exception ex){JOptionPane.showMessageDialog(frame,"Check salary and job-specific field values.");}
        });
        showPanel("Post New Job",f);
    }

    private static void reviewApplications(){
        Employer e=(Employer)currentUser;
        JPanel p=panel();p.setLayout(new BorderLayout(8,8));
        DefaultListModel<String> m=new DefaultListModel<>();
        for(String line:e.reviewApplications())m.addElement(line);
        JList<String> list=new JList<>(m);
        list.setCellRenderer(new DefaultListCellRenderer(){
            public Component getListCellRendererComponent(JList<?> l,Object v,int i,boolean s,boolean f){
                super.getListCellRendererComponent(l,v,i,s,f);String[] a=((String)v).split("\\|",-1);
                setText(a[0]+" | "+findApplicantName(a[1])+" | "+findJobTitle(a[2])+" | "+a[4]);
                return this;
            }});
        p.add(new JScrollPane(list),BorderLayout.CENTER);
        JPanel b=new JPanel();JButton accept=btn("Accept");JButton reject=btn("Reject");JButton schedule=btn("Schedule Interview");
        b.add(accept);b.add(reject);b.add(schedule);p.add(b,BorderLayout.SOUTH);
        accept.addActionListener(x->setApplicationStatus(list,"Accepted"));
        reject.addActionListener(x->setApplicationStatus(list,"Rejected"));
        schedule.addActionListener(x->scheduleSelected(list));
        showPanel("Review Applications",p);
    }

    private static String findApplicantName(String id){
        for(String line:FileHandler.readAll(FileHandler.USERS_FILE)){
            String[] p=line.split("\\|",-1);if(p.length>4&&p[0].equals(id))return p[4];
        }return id;
    }

    private static void setApplicationStatus(JList<String> list,String status){
        String line=list.getSelectedValue();if(line==null){JOptionPane.showMessageDialog(frame,"Select an application.");return;}
        String id=line.split("\\|",-1)[0];ArrayList<String> out=new ArrayList<>();
        for(String x:FileHandler.readAll(FileHandler.APPLICATIONS_FILE)){
            String[] p=x.split("\\|",-1);if(p.length>=5&&p[0].equals(id))p[4]=status;out.add(String.join("|",p));
        }
        FileHandler.writeAll(FileHandler.APPLICATIONS_FILE,out);reviewApplications();
    }

    private static void scheduleSelected(JList<String> list){
        String line=list.getSelectedValue();if(line==null){JOptionPane.showMessageDialog(frame,"Select an application.");return;}
        String[] a=line.split("\\|",-1);
        if(a.length<5||!a[4].equals("Accepted")){JOptionPane.showMessageDialog(frame,"Only accepted applications can be scheduled.");return;}
        JTextField date=new JTextField(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
        JTextField time=new JTextField("09:00");JTextField place=new JTextField();
        JPanel f=new JPanel(new GridLayout(0,2,5,5));f.add(new JLabel("Date"));f.add(date);f.add(new JLabel("Time"));f.add(time);f.add(new JLabel("Place"));f.add(place);
        int r=JOptionPane.showConfirmDialog(frame,f,"Schedule Interview",JOptionPane.OK_CANCEL_OPTION);
        if(r==JOptionPane.OK_OPTION){
            ((Employer)currentUser).scheduleAppointment(a[0],date.getText(),time.getText(),place.getText());
            JOptionPane.showMessageDialog(frame,"Interview scheduled.");
        }
    }

    private static void showPanel(String title,JPanel content){
        base("JobSync - "+title);
        JPanel root=new JPanel(new BorderLayout());
        JButton back=btn("← Dashboard");
        JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));top.add(back);
        root.add(top,BorderLayout.NORTH);root.add(content,BorderLayout.CENTER);
        back.addActionListener(e->showDashboard());
        frame.setContentPane(root);frame.setVisible(true);
    }
}
