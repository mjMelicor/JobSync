public abstract class User {
    private String userId;
    private String username;
    private String password;
    private String fullName;

    public User(String userId, String username, String password, String fullName) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.fullName = fullName;
    }

    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getFullName() { return fullName; }
    public void setPassword(String p) { password = p; }

    public boolean login(String u, String p) {
        return username.equals(u) && password.equals(p);
    }

    public abstract void displayMenu();

    protected String getPasswordForStorage() { return password; }
}
