import java.util.*;

public class JobManager {
    public static ArrayList<JobPosting> getAllJobs() {
        ArrayList<JobPosting> jobs = new ArrayList<>();
        for (String line : FileHandler.readAll(FileHandler.JOBS_FILE)) {
            JobPosting j = JobPosting.fromFileString(line);
            if (j != null) jobs.add(j);
        }
        return jobs;
    }

    public static void addJob(JobPosting job) {
        FileHandler.appendLine(FileHandler.JOBS_FILE, job.toFileString());
    }

    public static void updateJob(JobPosting job) {
        ArrayList<String> out = new ArrayList<>();
        for (JobPosting j : getAllJobs()) {
            out.add(j.getJobId().equals(job.getJobId()) ? job.toFileString() : j.toFileString());
        }
        FileHandler.writeAll(FileHandler.JOBS_FILE, out);
    }

    public static void deleteJob(String jobId) {
        ArrayList<String> out = new ArrayList<>();
        for (JobPosting j : getAllJobs())
            if (!j.getJobId().equals(jobId)) out.add(j.toFileString());
        FileHandler.writeAll(FileHandler.JOBS_FILE, out);
    }

    public static ArrayList<JobPosting> search(String title) {
        ArrayList<JobPosting> result = new ArrayList<>();
        for (JobPosting j : getAllJobs())
            if (j.getStatus().equals("Open") &&
                j.getTitle().toLowerCase().contains(title.toLowerCase()))
                result.add(j);
        return result;
    }

    public static ArrayList<JobPosting> search(String title, String location) {
        ArrayList<JobPosting> result = new ArrayList<>();
        for (JobPosting j : search(title))
            if (j.getLocation().toLowerCase().contains(location.toLowerCase()))
                result.add(j);
        return result;
    }

    public static ArrayList<JobPosting> search(double minSalary) {
        ArrayList<JobPosting> result = new ArrayList<>();
        for (JobPosting j : getAllJobs())
            if (j.getStatus().equals("Open") && j.getSalary() >= minSalary) result.add(j);
        return result;
    }

    public static ArrayList<JobPosting> getJobsForEmployer(String employerId) {
        ArrayList<JobPosting> result = new ArrayList<>();
        for (JobPosting j : getAllJobs())
            if (j.getEmployerId().equals(employerId)) result.add(j);
        return result;
    }
}
