import java.util.*;

public class Applicant extends User {
    private String contactNumber;
    private Resume resume;

    public Applicant(String id, String username, String password, String fullName,
                     String contactNumber, Resume resume) {
        super(id, username, password, fullName);
        this.contactNumber = contactNumber;
        this.resume = resume;
    }

    public String getContactNumber() { return contactNumber; }
    public Resume getResume() { return resume; }
    public void setContactNumber(String n) { contactNumber = n; }
    public void setResume(Resume r) { resume = r; }

    @Override
    public void displayMenu() {
        System.out.println("Applicant menu");
    }

    public void applyForJob(String jobId) {
        String appId = "A" + System.currentTimeMillis();
        String date = new java.text.SimpleDateFormat("yyyy-MM-dd").format(new Date());
        FileHandler.appendLine(FileHandler.APPLICATIONS_FILE,
                String.join("|", appId, getUserId(), jobId, date, "Pending"));
    }

    public ArrayList<String> viewMyApplications() {
        ArrayList<String> result = new ArrayList<>();
        for (String line : FileHandler.readAll(FileHandler.APPLICATIONS_FILE)) {
            String[] p = line.split("\\|", -1);
            if (p.length >= 5 && p[1].equals(getUserId())) result.add(line);
        }
        return result;
    }

    public ArrayList<String> viewMyAppointments() {
        ArrayList<String> result = new ArrayList<>();
        for (String line : FileHandler.readAll(FileHandler.APPOINTMENTS_FILE)) {
            String[] p = line.split("\\|", -1);
            if (p.length >= 5) {
                for (String app : viewMyApplications()) {
                    String[] a = app.split("\\|", -1);
                    if (a.length >= 1 && a[0].equals(p[1])) {
                        result.add(line);
                        break;
                    }
                }
            }
        }
        return result;
    }

    public void withdrawApplication(String id) {
        ArrayList<String> lines = FileHandler.readAll(FileHandler.APPLICATIONS_FILE);
        ArrayList<String> out = new ArrayList<>();
        for (String line : lines) {
            String[] p = line.split("\\|", -1);
            if (!(p.length >= 5 && p[0].equals(id) && p[1].equals(getUserId()))) {
                out.add(line);
            }
        }
        FileHandler.writeAll(FileHandler.APPLICATIONS_FILE, out);
    }
}
