public class FullTimeJob extends JobPosting {
    private String workSchedule;

    public FullTimeJob(String id, String title, String description, String location,
                       String skills, double salary, String employerId, String status,
                       String workSchedule) {
        super(id,title,description,location,skills,salary,employerId,status);
        this.workSchedule = workSchedule;
    }

    public String getWorkSchedule() { return workSchedule; }
    public void setWorkSchedule(String s) { workSchedule = s; }

    @Override public String getBenefits() {
        return "Regular employment; " + workSchedule;
    }

    @Override public double computeMonthlySalary() {
        return salary;
    }

    @Override protected String getType() { return "FULL_TIME"; }
    @Override protected String getExtra() { return workSchedule; }
}
