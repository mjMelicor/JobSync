public class Appointment {
    private String appointmentId;
    private String applicationId;
    private String date;
    private String time;
    private String place;

    public Appointment(String appointmentId, String applicationId,
                       String date, String time, String place) {
        this.appointmentId=appointmentId; this.applicationId=applicationId;
        this.date=date; this.time=time; this.place=place;
    }

    public String getAppointmentId(){return appointmentId;}
    public String getApplicationId(){return applicationId;}
    public String getDate(){return date;}
    public String getTime(){return time;}
    public String getPlace(){return place;}

    public String toFileString() {
        return String.join("|",appointmentId,applicationId,date,time,place);
    }
}
