import java.io.*;
import java.util.*;

public class FileHandler {
    public static final String USERS_FILE = "data/users.txt";
    public static final String JOBS_FILE = "data/jobs.txt";
    public static final String APPLICATIONS_FILE = "data/applications.txt";
    public static final String APPOINTMENTS_FILE = "data/appointments.txt";

    public static ArrayList<String> readAll(String file) {
        ArrayList<String> lines = new ArrayList<>();
        try {
            File f = new File(file);
            if (!f.exists()) {
                File parent = f.getParentFile();
                if (parent != null) parent.mkdirs();
                f.createNewFile();
                return lines;
            }
            try (BufferedReader br = new BufferedReader(new FileReader(f))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (!line.trim().isEmpty()) lines.add(line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lines;
    }

    public static void appendLine(String file, String line) {
        try {
            File f = new File(file);
            File parent = f.getParentFile();
            if (parent != null) parent.mkdirs();
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(f, true))) {
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeAll(String file, ArrayList<String> lines) {
        try {
            File f = new File(file);
            File parent = f.getParentFile();
            if (parent != null) parent.mkdirs();
            try (BufferedWriter bw = new BufferedWriter(new FileWriter(f))) {
                for (String line : lines) {
                    bw.write(line);
                    bw.newLine();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
