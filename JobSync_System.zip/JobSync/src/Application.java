public class Application {
    private String applicationId;
    private String applicantId;
    private String jobId;
    private String dateApplied;
    private String status;

    public Application(String applicationId, String applicantId, String jobId,
                       String dateApplied, String status) {
        this.applicationId=applicationId; this.applicantId=applicantId;
        this.jobId=jobId; this.dateApplied=dateApplied;
        setStatus(status);
    }

    public String getApplicationId() { return applicationId; }
    public String getApplicantId() { return applicantId; }
    public String getJobId() { return jobId; }
    public String getDateApplied() { return dateApplied; }
    public String getStatus() { return status; }

    public void setStatus(String s) {
        if (!s.equals("Pending") && !s.equals("Accepted") &&
            !s.equals("Rejected")) {
            throw new IllegalArgumentException("Invalid application status.");
        }
        status=s;
    }

    public String toFileString() {
        return String.join("|",applicationId,applicantId,jobId,dateApplied,status);
    }
}
