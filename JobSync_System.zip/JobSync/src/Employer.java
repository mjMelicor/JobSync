import java.util.*;

public class Employer extends User {
    private String companyName;
    private String companyAddress;

    public Employer(String id, String username, String password, String fullName,
                    String companyName, String companyAddress) {
        super(id, username, password, fullName);
        this.companyName = companyName;
        this.companyAddress = companyAddress;
    }

    public String getCompanyName() { return companyName; }
    public String getCompanyAddress() { return companyAddress; }
    public void setCompanyName(String s) { companyName = s; }
    public void setCompanyAddress(String s) { companyAddress = s; }

    @Override
    public void displayMenu() {
        System.out.println("Employer menu");
    }

    public void post(JobPosting job) {
        JobManager.addJob(job);
    }

    public ArrayList<String> reviewApplications() {
        ArrayList<String> result = new ArrayList<>();
        for (String app : FileHandler.readAll(FileHandler.APPLICATIONS_FILE)) {
            String[] a = app.split("\\|", -1);
            if (a.length >= 5) {
                for (JobPosting job : JobManager.getJobsForEmployer(getUserId())) {
                    if (job.getJobId().equals(a[2])) {
                        result.add(app);
                        break;
                    }
                }
            }
        }
        return result;
    }

    public void scheduleAppointment(String appId, String date, String time, String place) {
        // one appointment per accepted application
        ArrayList<String> lines = FileHandler.readAll(FileHandler.APPOINTMENTS_FILE);
        String appointmentId = "AP" + System.currentTimeMillis();
        FileHandler.appendLine(FileHandler.APPOINTMENTS_FILE,
                String.join("|", appointmentId, appId, date, time, place));
    }
}
